import {Column} from "../entities/column";
import {RowNode} from "../entities/rowNode";

export interface IContextMenuFactory {

    showMenu(node: RowNode, column: Column, value: any, mouseEvent: MouseEvent): void;

}